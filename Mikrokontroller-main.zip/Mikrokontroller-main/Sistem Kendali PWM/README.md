
# Sistem Kendali PWM

## Hasil Pengujian:

https://github.com/subaaaiii/Mikrokontroller/assets/134286891/a95f6407-1e2d-45fb-8c5b-5bda2f154ffd




