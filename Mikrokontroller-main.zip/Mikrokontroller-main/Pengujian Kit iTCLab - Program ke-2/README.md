
# Pengujian Kit iTCLab - Program ke-2

## Pengaturan References:

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-1/Preferences.jpg" alt="" class="img-responsive" width="400">
</p>

## Pengaturan Board dan port:

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-1/BoardPort.jpg" alt="" class="img-responsive" width="400">
</p>

## Hasil Output Pada Serial Monitor :

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-2/HasilOutput.jpg" alt="" class="img-responsive" width="400">
</p>
