
# Pengujian Kit iTCLab - Program ke-1

## Pengaturan References:

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-1/Preferences.jpg" alt="" class="img-responsive" width="400">
</p>

## Pengaturan Board dan port:

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-1/BoardPort.jpg" alt="" class="img-responsive" width="400">
</p>

## Kendala :

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-1/Kendala.jpg" alt="" class="img-responsive" width="400">
</p>

Terdapat kendala pada fungsi AnalogWrite, fungsi hanya membutuhkan 3 paramterer, sedangkan dalam program dipassing 5 parameter, kemungkinan beda versi analogwrite atau terdapat update fungsi analogwrite itu sendiri.
berikut analisa menggunaka AI : CHATGPT 
<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Pengujian%20Kit%20iTCLab%20-%20Program%20ke-1/AI.jpg" alt="" class="img-responsive" width="400">
</p>
