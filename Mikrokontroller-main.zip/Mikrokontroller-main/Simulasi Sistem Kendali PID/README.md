
# Sistem Kendali PID

## Library Yang dibutuhkan:

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Simulasi%20Sistem%20Kendali%20PID/library.jpg" alt="" class="img-responsive" width="700">
</p>

## Output:

<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Simulasi%20Sistem%20Kendali%20PID/Output1.jpg" alt="" class="img-responsive" width="400">
</p>
Output berupa diagram komponen PID, yaitu set point, PID(Proportional, integral, derrivatif) Error an time.
parameter Kc kaul dan tauD dapat dimanipulasi agar mendapatkan output atau keluaran yang diinginkan.
<p>
  <img src="https://github.com/subaaaiii/Mikrokontroller/blob/main/Simulasi%20Sistem%20Kendali%20PID/Output2.jpg" alt="" class="img-responsive" width="400">
</p>

